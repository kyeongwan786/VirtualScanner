"""Desktop review interface."""
