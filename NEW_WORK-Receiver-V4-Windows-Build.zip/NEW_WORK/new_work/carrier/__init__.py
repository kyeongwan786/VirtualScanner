"""Carrier-specific output adapters."""
