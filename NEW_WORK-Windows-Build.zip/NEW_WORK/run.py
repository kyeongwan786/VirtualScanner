from new_work.gui.app import main


if __name__ == "__main__":
    main()
