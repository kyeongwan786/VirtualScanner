NEW_WORK V1 Windows 빌드 안내
============================

V1은 예전 OCR 창에 현재 OCR 알고리즘을 적용한 OCR 전용 버전입니다. PDF 추가,
접수 PC 선택, Relay 전송 기능이 없으며, 사용할 접수 PC에서 실행하세요.
창 가로 폭은 예전 설정인 560px로 유지하고, OCR 결과 행 수와 신분증 비율에 맞춰
세로 길이를 자동으로 조정합니다.

저장 동작
---------
- SK: C:\SKT-UScan\agent\WEB-INF\classes\sk_report.txt 갱신
- KT: C:\IMAGE\myCustomer.db의 T_SCAN_PAPER 갱신, C:\IMAGE\ORG.jpg와 CR.jpg 생성
- 지원되는 신분증 종류는 미리보기에서 고정 크기 파란 크롭 영역을 표시합니다.
  영역을 드래그해 옮기거나 영역 밖을 클릭해 새 위치를 지정한 뒤 저장하면,
  SK의 idCrop 또는 KT의 CR.jpg에 해당 영역이 반영됩니다. 크롭 크기와 저장 크기는
  신분증 종류별 규격을 사용하며, SK는 idCrop 대상 종류만 제공합니다.
- 얼굴 자동 검출이 실패해도 파란 기본 영역을 표시합니다. 이 경우 영역을 직접
  옮겨 확인해야 저장할 수 있어, 잘못된 위치를 자동으로 얼굴 이미지로 저장하지 않습니다.
- 자동 얼굴 영역을 다시 쓰려면 "자동 영역 복원"을 누르세요.

빌드
----
이 V1 전용 ZIP을 풀고 Windows x64에서 Python 3.12 x64를 설치한 뒤
build_windows_v1.bat을 실행하세요. 이 스크립트는 V1 빌드를 명시적으로 선택합니다.
성공하면 dist\new_work_v1\new_work_v1.exe가 생성됩니다.
이 ZIP은 빌드 소스이며 완성된 Windows EXE를 포함하지 않습니다.

V1은 직접 저장하는 OCR 전용 프로그램이므로 별도 Receiver가 필요하지 않습니다.
접수 PC를 원격으로 선택해 전송하려면 V2 중앙 앱과 V2 Receiver를 쓰세요.
V1은 Windows 로그인 자동 실행을 등록하지 않으며, 기존 V1 자동 실행 항목이 있으면
V1을 한 번 실행할 때 제거합니다.
